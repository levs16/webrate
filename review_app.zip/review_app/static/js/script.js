document.addEventListener('DOMContentLoaded', function() {
    const stars = document.querySelectorAll('.star');
    stars.forEach(function(star, index) {
        star.addEventListener('click', function() {
            let ratingInput = document.querySelector('input[name="starsObjectRate"]');
            ratingInput.value = index + 1; // Set rating in hidden form field
            updateStars(index);
        });
    });

    function updateStars(index) {
        stars.forEach((star, i) => {
            if (i <= index) {
                star.textContent = '★'; // Filled star
            } else {
                star.textContent = '☆'; // Empty star
            }
        });
    }
});