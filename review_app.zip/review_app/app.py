from flask import Flask, render_template, request, redirect, url_for
from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SubmitField
from wtforms.validators import DataRequired
import json
import os
import json.decoder

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yes!!!'

class ReviewForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    reviewSubject = StringField('Review Subject', validators=[DataRequired()])
    reviewText = TextAreaField('Review Text', validators=[DataRequired()])
    submit = SubmitField('Submit Review')

def load_reviews():
    if os.path.exists('reviews.json'):
        with open('reviews.json', 'r') as f:
            try:
                return json.load(f)
            except json.decoder.JSONDecodeError:
                # Return an empty list if the file is empty
                return []
    else:
        return []

def save_review(review):
    reviews = load_reviews()
    reviews.append(review)
    with open('reviews.json', 'w') as f:
        json.dump(reviews, f)

@app.route('/', methods=['GET', 'POST'])
def index():
    form = ReviewForm()
    if form.validate_on_submit():
        review = {
            'username': form.username.data,
            'reviewSubject': form.reviewSubject.data,
            'reviewText': form.reviewText.data,
            # Placeholder for starsObjectRate, implement according to your JS logic
            'starsObjectRate': request.form.get('starsObjectRate', 0)
        }
        save_review(review)
        return redirect(url_for('index'))
    reviews = load_reviews()
    return render_template('index.html', form=form, reviews=reviews)

if __name__ == '__main__':
    app.run(debug=True)